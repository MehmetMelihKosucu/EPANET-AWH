// stdafx.h - Precompiled header
#pragma once

// Standard C++ libraries
#include <vector>
#include <string>
#include <algorithm>
#include <memory>
#include <map>

// C Standard libraries (if needed)
#include <stdlib.h>
#include <stdio.h>
#include <math.h>